#include "cv.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main() {
	Ptr<BackgroundSubtractor> bg_model = createBackgroundSubtractorMOG2();
	Mat img, kernel, avg, foreground, foregroundMask;
	VideoCapture cap("people.avi");

	vector<vector < Point >> contours;
	vector<Vec4i>hierarchy;

	kernel = getStructuringElement(MORPH_ELLIPSE, Size(30, 30));
	foreground = Mat(img.size(), CV_8UC3, Scalar(255, 255, 255));

	while (true) {

		cap >> img;

		if (img.empty())
			break;

		resize(img, img, Size(640, 480));

		if (foregroundMask.empty())
			foregroundMask.create(img.size(), img.type());

		bg_model->apply(img, foregroundMask, true ? -1 : 0);

		GaussianBlur(foregroundMask, foregroundMask, Size(11, 11), 3.5,  3.5);

		threshold(foregroundMask, foregroundMask, 150, 255, THRESH_BINARY);

		dilate(foregroundMask, foregroundMask, kernel);

		findContours(foregroundMask, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);

		for (int i = 0; i < contours.size(); i++) {
			drawContours(foregroundMask, contours, i, Scalar(0, 255, 0), CV_FILLED, 8, hierarchy);
			Rect rect = boundingRect(contours[i]); 
			if (rect.area() > 1000) {
				rectangle(img, rect.tl(), rect.br(), Scalar(0, 0, 255), 2, 8, 0);
			}
			putText(img, "People Number: "+to_string(contours.size()), Point(50, 100), FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 0, 255), 4);
		}

		imshow("avg", img);

		waitKey(cap.get(CAP_PROP_FPS));
	}
}