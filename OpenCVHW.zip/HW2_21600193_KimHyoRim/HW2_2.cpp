#include "cv.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main() {

	Mat img, img_y, mask, foreground;

	img = imread("hand.png");

	resize(img, img, Size(400, 500), 0, 0, CV_INTER_LINEAR);

	img_y = img.clone();
	cvtColor(img_y, img_y, CV_BGR2YCrCb);
	
	inRange(img_y, Scalar(0, 133, 77), Scalar(255, 173, 127), mask);

	foreground = Mat(img.size(), CV_8UC3, Scalar(255, 255, 255));
	img.copyTo(foreground, mask);

	imshow("Foreground", foreground);

	waitKey(0);

	return 0;
}