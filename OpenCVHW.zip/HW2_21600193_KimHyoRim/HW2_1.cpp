#include "cv.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main() {
	Mat frame, edge, result;
	Point p1, p2;
	vector<Vec4i> lines1;
	Vec4i l ;

	double degree1, sumx1, sumy1, sumx2,sumy2, num1, num2, sum2x1, sum2y1, sum2x2,sum2y2;

	double x1, x2, y1, y2, fx1, fx2, fy1, fy2;

	float rho, theta, a, b, x0, y0;

	VideoCapture cap("lane.mp4");


	while (1) {
		cap >> frame;

		if (frame.empty()) {
			break;
		}

		Rect rect1(frame.size().width / 3, frame.size().height / 4, frame.size().width / 2.5, frame.size().height / 2);

		result = frame.clone();

		cvtColor(frame, edge, CV_BGR2GRAY);

		Canny(frame, edge, 260, 440);
		sumx1 = 0;
		sumx2 = 0;
		sumy1 = 0;
		sumy2 = 0;
		sum2x1 = 0;
		sum2x2 = 0;
		sum2y1 = 0;
		sum2y2 = 0;
		num1 = 0;
		num2 = 0;

		HoughLinesP(edge(rect1), lines1, 1, CV_PI/180, 50, 10, 300);
		for (int i = 0; i < lines1.size(); i++) {
			l = lines1[i];
			degree1 = 180 * atan2((float)(l[3] - l[1]), (float)(l[2] - l[0])) /	CV_PI;

			if (degree1 > 30 && degree1 < 50) {
				num1++;
				sumx1 += l[0];
				sumy1 += l[1];
				sumx2 += l[2];
				sumy2 += l[3];
			}
			else if (degree1 <-30 && degree1 > -50) {
				num2++;
				sum2x1 += l[0];
				sum2y1 += l[1];
				sum2x2 += l[2];
				sum2y2 += l[3];
			}
		}
		x1 = sumx1 / num1 + frame.size().width / 3;
		y1 = sumy1 / num1 + frame.size().height / 4;
		x2 = sumx2 / num1 + frame.size().width / 3;
		y2 = sumy2 / num1 + frame.size().height / 4;

		fx2 = x1 - (y1*(x1 - x2) / (y1 - y2));
		fx1 = x2 + (x1 - x2)*(frame.size().height - y2) / (y1 - y2);

		line(result, Point(fx1, frame.size().height), Point(fx2, 0), Scalar(0, 0, 255), 3, 8);

		x1 = sum2x1 / num2 + frame.size().width / 3;
		y1 = sum2y1 / num2 + frame.size().height / 4;
		x2 = sum2x2 / num2 + frame.size().width / 3;
		y2 = sum2y2 / num2 + frame.size().height / 4;

		fx1 = x2-((frame.size().height - y2)*(x2 - x1) / (y1 - y2));
		fx2 = y1*(x2 - x1) / (y1 - y2) + frame.size().width / 3;

		line(result, Point(fx1, frame.size().height), Point(fx2, 0), Scalar(0, 0, 255), 3, 8);

		imshow("WindowResult", result);

		waitKey(cap.get(CAP_PROP_FPS));
	}
}